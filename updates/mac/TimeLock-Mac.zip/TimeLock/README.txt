TimeLock for Mac v1.2.0 — tracks your time in apps (macOS 13+)
https://github.com/jonpikereally/TimeLock

INSTALL
1. Double-click "Install TimeLock.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Look for the hourglass in the menu bar. TimeLock needs no permissions.

WHAT IT DOES
• Counts time in the app you're using. Pauses after a minute with no mouse
  or keyboard input (unless a video is playing) and when the screen locks.
• Works with the TimeLock browser extension: your app time shows in the
  extension, a daily limit can include apps (e.g. "Social: x.com + Discord"),
  and this menu shows your website time and limits. Apps are never locked;
  when a limit runs out, its websites lock.

PRIVACY
Everything stays on your Mac (~/Library/Application Support/TimeLock).
No accounts, no analytics. The only thing TimeLock fetches from the internet
is a small version file from the GitHub repo above, to check for updates.
