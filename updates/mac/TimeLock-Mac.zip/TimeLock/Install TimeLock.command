#!/bin/bash
# TimeLock installer — copies the app to ~/Applications and launches it.
cd "$(dirname "$0")"
fail() {
  echo
  echo "Error $1: $2"
  echo "Look up this code on the TimeLock error list:"
  echo "  https://github.com/jonpikereally/TimeLock/blob/main/ERRORS.md"
  echo "(You can also give that page to an AI assistant for help.)"
  exit 1
}
echo "Installing TimeLock…"
mkdir -p ~/Applications || fail TL-801 "Couldn't create ~/Applications."
osascript -e 'quit app id "com.jonpike.timelock"' 2>/dev/null
rm -rf ~/Applications/TimeLock.app
ditto --norsrc TimeLock.app ~/Applications/TimeLock.app \
  || fail TL-801 "Couldn't copy TimeLock into ~/Applications."
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine ~/Applications/TimeLock.app 2>/dev/null
codesign --force --sign - ~/Applications/TimeLock.app 2>/dev/null \
  || fail TL-802 "Couldn't sign TimeLock for this Mac."
open ~/Applications/TimeLock.app \
  || fail TL-803 "TimeLock was installed but couldn't be opened. Open it from ~/Applications yourself."
echo
echo "Done! Look for the hourglass in your menu bar."
echo "If the TimeLock browser extension is installed, reload it once so it connects."
